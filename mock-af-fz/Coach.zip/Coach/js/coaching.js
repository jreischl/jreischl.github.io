// JavaScript Document

$("header").load("includes/header.html");
$("#navbar").load("includes/nav.html");
		
$("footer").load("includes/footer.html");



